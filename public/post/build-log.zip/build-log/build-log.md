---
title: "网站折腾记录～"
slug: build-log
date: 2023-01-05T17:08:51+08:00
description: "Built with Hugo,Theme Stack"
image: https://hugo-blog-1307365020.cos.ap-nanjing.myqcloud.com/p/build-log/cover.jpg
categories:
    - Hugo
    - Blog
---
## 搭建Hugo环境
⚠️这里以macOS为例，其他系统请自行前往 https://gohugo.io/installation/ 了解
### 安装Homebrew
在终端中使用以下命令
```sh
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```
>如果出现 `curl: (7) Failed to connect to raw.githubusercontent.com port 443: Operation timed out` 错误，可以使用下面的国内源
```sh 
/bin/bash -c "$(curl -fsSL https://gitee.com/ineo6/homebrew-install/raw/master/install.sh)"
``` 

